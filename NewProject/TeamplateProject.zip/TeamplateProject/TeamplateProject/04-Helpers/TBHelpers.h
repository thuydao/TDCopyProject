//
//  TBHelpers.h
//  TeamplateProject
//
//  Created by thuydd on 1/29/15.
//  Copyright (c) 2015 Qsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TBHelpers : NSObject

/**
 *  sharedInstance
 *
 *  @return instancetype
 */
+ (instancetype)sharedInstance;

@end
