//
//  QSAppDelegate.m
//  TeamplateProject
//
//  Created by thuydd on 1/15/15.
//  Copyright (c) 2015 Qsoft. All rights reserved.
//

#import "TBAppDelegate.h"
#import "TDReachability.h"

@implementation TBAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [TDReachability shared];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
}

- (void)applicationWillTerminate:(UIApplication *)application {
}

@end
