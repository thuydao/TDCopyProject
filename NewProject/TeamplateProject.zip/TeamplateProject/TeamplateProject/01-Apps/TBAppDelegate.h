//
//  QSAppDelegate.h
//  TeamplateProject
//
//  Created by thuydd on 1/15/15.
//  Copyright (c) 2015 Qsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
