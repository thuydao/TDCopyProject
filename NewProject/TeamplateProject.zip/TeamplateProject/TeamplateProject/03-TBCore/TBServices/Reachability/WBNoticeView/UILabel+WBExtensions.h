//
//  UILabel+WBExtensions.h
//  NoticeView
//
//  Created by Tito Ciuro on 5/15/12.
//  Copyright (c) 2012 Tito Ciuro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (WBExtensions)

- (NSArray *)lines;

@end
