//
//  TDEngineLog.h
//  TDEngineLog
//
//  Created by Dao Duy Thuy on 10/22/14.
//  Copyright (c) 2014 TD. All rights reserved.
//

#import <UIKit/UIKit.h>

#define EMAIL_DEVELOPMENT @"daoduythuy@gmail.com"
#define FILE_LENGTH 1000000
#define TD_DEBUG 1

#import "NSObject+File.h"
#import "TDLog.h"
#import "UIViewController+TDLog.h"

