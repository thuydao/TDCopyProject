# TDEngineLog


Development by : Thuỷ Đào

Phone: +84 932 220 664

Email: daoduythuy@gmail.com

Technical Leader Qsoft Viet Nam


//===========================================================

Using in Testing & UAT phase 

User can send log file to mail of development


Setting in TDEngineLog.h file

overwrite

emailDevelopment @"daoduythuy@gmail.com"

FILE_LENGTH 1000000


sample: TDLog(@"text log");
