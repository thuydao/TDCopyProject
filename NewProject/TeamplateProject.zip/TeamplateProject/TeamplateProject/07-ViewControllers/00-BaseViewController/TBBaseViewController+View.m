//
//  QSBaseViewController+View.m
//  TeamplateProject
//
//  Created by thuydd on 1/29/15.
//  Copyright (c) 2015 Qsoft. All rights reserved.
//

#import "TBBaseViewController+View.h"

@implementation TBBaseViewController (View)

@end
